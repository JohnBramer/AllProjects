#include <iostream>
#include <string>
#include "Region.h"
#include "Mapmaker.h"
#include "functions.h"
using namespace std;

Region::Region(){
	//cout << "start" << endl;
}

string Region::getOne(){
	return region_one;
}

void Region::initial_grid(){
	for(int k = 0; k<=9; k++){ //9 for lengths
		for(int i = 0; i<= 3; i++){ //3 for wide
			int temp_num = rand()%(101);
			if(temp_num <= 20){ //random number chance
				grid[k][i] = 'A';
			}else if(temp_num >= 20 && temp_num <= 57){ //random number chance
				grid[k][i] = 'D';
			}else{
				grid[k][i] = 'P';
			}

	}
	
	}

}

Region::Region(string r_one){
	region_one = r_one;
	initial_grid();
}




char Region::getSpot(int pos_one, int pos_two){ 
	return grid[pos_one][pos_two];
}



