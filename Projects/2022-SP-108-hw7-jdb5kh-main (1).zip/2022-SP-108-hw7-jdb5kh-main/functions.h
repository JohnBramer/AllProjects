#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <iostream>
#include <string>

using namespace std;

//Des: This function displays the summary of the game
//pre: none
//post: summary of the two maps after exploration
void summary(Mapmaker & m1, Mapmaker & m2);



#endif