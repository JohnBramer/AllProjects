#ifndef REGION_H
#define REGION_H
#include <iostream>
#include <string>

using namespace std;

class Region{
	public:
		//Pre: This is a default constructor
		//pre: none
		//post: this class was initialized
		Region();
		//Pre: This is a constructor that gets our name
		//pre: none
		//post: the name is set in our Region class
		Region(string r_one);
		// member class functions
		//Pre: This is a function to return our region name
		//pre: none
		//post: our region name will be returned
		string getOne();
		//Pre: This is a function to get coordinated for our playermap
		//pre: none
		//post: an x and y will be returned from our playermap
		char getSpot(int pos_one, int pos_two);
		//Pre: This is a function to initalize our grid
		//pre: none
		//post: our char grid will be set to random A's, D's, and P's
		void initial_grid();
		
	
	private:
		string region_one;
		char grid[10][4];
	
	
	
};	










#endif