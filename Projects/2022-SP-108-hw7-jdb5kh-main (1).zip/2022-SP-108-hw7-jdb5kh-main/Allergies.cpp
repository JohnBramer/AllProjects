// Programmer: John Bramer
// Student ID: <jdb5kh>
// Section: <108>
// Date: 4/18/2022
// File: Allergies.cpp
// Assignment: HW7
// Purpose: This is a map exploration game
#include <iostream>
#include <string>
#include "Region.h"
#include "Mapmaker.h"
#include "functions.h"
using namespace std;

int main(){
	//Region f;
	string player_name;
	string player_two_name;
	string region_name;
	int round_count = 1;
	srand(278);
	
	cout << "Welcome, Please enter a name for your region!" << endl;
	getline(cin, region_name);
	Region region(region_name);
	cout << region.getOne() << endl;
	
	cout << "Now, please enter your two players!" << endl;
	Mapmaker f;
	getline(cin, player_name);
	Mapmaker m1(player_name);
	getline(cin, player_two_name);
	Mapmaker m2(player_two_name);
	
	m1.initial_map();
	m2.initial_map();
	
	
	
	
	while(m1.check_map() == true && m2.check_map() == true && round_count <= 150){
		cout << "ROUND: " << round_count << endl;
		cout << "\t" << m1.getName() << ":" << endl;	
		m1.explore_map(region);
		rockPaperScissors(m1, m2);
		cout << "\t" << m2.getName() << ":" << endl;
		m2.explore_map(region);
		rockPaperScissors(m1, m2);
		round_count++;
	}
	
	summary(m1, m2);
	return 0;
	
}	
