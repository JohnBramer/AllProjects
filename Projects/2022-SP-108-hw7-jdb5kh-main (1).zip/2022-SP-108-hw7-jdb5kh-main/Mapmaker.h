#ifndef MAPMAKER_H
#define MAPMAKER_H
#include <iostream>
#include <string>

using namespace std;

class Mapmaker{
	public:
		//Pre: This is a default constructor
		//pre: none
		//post: this class was initialized
		Mapmaker();
		//Pre: This is a default constructor, that takes in our mapmaker name
		//pre: none
		//post: the map maker name was initialized
		Mapmaker(string name);
		//Pre: This is a constructor that gets our name
		//pre: none
		//post: the name is set in our mapmaker class
		string getName();
		//Pre: This is a function to add 'U's to our map
		//pre: none
		//post: the Map was initialized
		void initial_map();
		//Pre: This function checks the map to see if there are still locations to explore
		//pre: none
		//post: true or false ift theyre are still U's
		bool check_map();
		//Pre: This function explores our map with random x and y values
		//pre: none
		//post: A location from region will be copied to the mapmaker map
		void explore_map(Region & region);
		//Pre: This is a function to help print out our coordinates
		//pre: none
		//post: two charactes for each of our coordinates will be returned
		char getSpot(int pos_one, int pos_two);
		
		friend Mapmaker rockPaperScissors(Mapmaker & m1, Mapmaker & m2);
		int rps_count;
		int uncharted_locations;
		int locations_explored;
		
	
	private:
		string player;
		char playerMap[10][4];
	
};	

Mapmaker rockPaperScissors(Mapmaker & m1, Mapmaker & m2);









#endif