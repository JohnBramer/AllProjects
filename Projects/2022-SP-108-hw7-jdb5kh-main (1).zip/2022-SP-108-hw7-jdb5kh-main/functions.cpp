#include <iostream>
#include <string>
#include "Region.h"
#include "Mapmaker.h"
#include "functions.h"
using namespace std;



void summary(Mapmaker & m1, Mapmaker & m2){
	cout << "COMPETITION SUMMARY" << endl;
	cout << "\t" << m1.getName() << ":" << endl;
	cout << "\t" << "Map" << ":" << endl;
	for(int i = 0; i<= 9; i++){
		for(int g = 0; g<=3; g++){
			cout <<"   "<< m1.getSpot(i, g);
		}
		cout << "\t" << endl;
	}
	cout << "Number of locations explored: " << m1.locations_explored << endl;
	cout << "Number of Rock Paper Scissors won: " << m1.rps_count << endl;


	cout << "\t" << m2.getName() << ":" << endl;
	cout << "\t" << "Map" << ":" << endl;
	for(int i = 0; i<= 9; i++){
		for(int g = 0; g<=3; g++){
			cout <<"   "<< m2.getSpot(i, g);
		}
		cout << "\t" << endl;
	}
	cout << "Number of locations explored: " << m2.locations_explored << endl;
	cout << "Number of Rock Paper Scissors won: " << m2.rps_count << endl;
	
	
}	