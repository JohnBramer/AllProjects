#include <iostream>
#include <string>
#include "Region.h"
#include "Mapmaker.h"
#include "functions.h"
using namespace std;

Mapmaker::Mapmaker(){
	//cout << "Please Enter the name for each player" << endl;
}


Mapmaker::Mapmaker(string name){
	player = name;
	uncharted_locations = 40;
	locations_explored = 0;
	rps_count = 0;
}


string Mapmaker::getName(){
	return player;
}

void Mapmaker::initial_map(){
	for(int i = 0; i<= 9; i++){
		for(int b = 0; b<= 3; b++){
			playerMap[i][b] = 'U';
			//cout << playerMap[i][b] << endl;
		}
	}
}

bool Mapmaker::check_map(){
	bool temp = false;
	for(int h = 0; h<= 9; h++){
		for(int m = 0; m<= 3; m++){
			if(playerMap[h][m] == 'U'){
				temp = true;
			}
			//cout << playerMap[h][m] << endl;
		}
	}
	if(temp != true){
		temp = false; //[grader] This is unneccesary, temp can only be true or false, so if it's not true, then it's already false and there's no need to set it to false here.
	}
	
	return temp;
}

void Mapmaker::explore_map(Region & region){
	int pos_one = rand() % (11);
	int pos_two = rand() % (5);
	cout << "Exploring location " << "[" << pos_one << "]" << "[" << pos_two << "]" << endl;
	if(playerMap[pos_one][pos_two] == 'U'){
		playerMap[pos_one][pos_two] = region.getSpot(pos_one, pos_two);
		if(playerMap[pos_one][pos_two] == 'P'){
			cout << "Pollen travels a long trajectory!" << endl;
			uncharted_locations--;
			locations_explored++;
		}else if(playerMap[pos_one][pos_two] == 'D'){
			cout << "Dust will never leave!" << endl;
			uncharted_locations--;
			locations_explored++;
		}else if(playerMap[pos_one][pos_two] == 'A'){
			cout << "Animals shed serious dander!" << endl;	
			uncharted_locations--;
			locations_explored++;
		
		}
	}else{
		cout << "visited" << endl;
	}
	cout << "Number of uncharted locations remaining: " << uncharted_locations << endl;
}

char Mapmaker::getSpot(int pos_one, int pos_two){
	return playerMap[pos_one][pos_two];
}

Mapmaker rockPaperScissors(Mapmaker & m1, Mapmaker & m2){
	//[grader] -10 This isn't really a rock paper scissors implementation, it's just a 3-way random number generator.
	//[grader] https://discord.com/channels/484488871015350295/484797197867679764/964307373676187669 
	Mapmaker m3;
	int temp_num = (rand()%(100))+1;
	if(temp_num <= 33){
		cout << m1.getName() << " won the rock paper scissors game!" << endl;
		m1.rps_count++;
		return m1.getName();
	}else if(temp_num <= 66){
		cout << m2.getName() << " won the rock paper scissors game!" << endl;
		m2.rps_count++;
		return m2.getName();
	}else{
		cout << " It looks like it was a tie" << endl;
		return m3.getName();
	}
	
}
