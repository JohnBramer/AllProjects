// Example program
#include <iostream>
#include <string>

using namespace std;
//des: this function creates an array and randomizes the numbers in it
//pre: none
//post: a random array of size 10
void initArray(int array[], int array_size);
//des: this function prints the min and max of the array
//pre: none
//post: the min and max of the array
void printMinMax(int array[], int array_size);

int main()
{
    srand(time(NULL));
    const int array_size = 10;
    int array[array_size];
    
    initArray(array, array_size);
    printMinMax(array, array_size);
}

void initArray(int array[], int array_size){
    for(int i = 0; i<= array_size-1; i++){
     array[i] = (rand() % (901)) + 100;
     cout << array[i] << endl;
    
    }
}

void printMinMax(int array[], int array_size){
    int max = array[0];
    int min = array[0];
    for (int k = 0; k <= array_size-1; k++)
    {
      if (array[k] > max)
        {
          max = array[k];
        }
      else if (array[k] < min)
        {
          min = array[k];
        }
    }
    cout << "The Max number is " << min << endl;
    cout << "The Min number is "<< max << endl;
}
