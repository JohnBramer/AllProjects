#include "helper.h"

using namespace std;
void computeRating(phone & allPhones){
  int total_score = 0;
  total_score = (2*allPhones.cpu_score) + (allPhones.gpu_score) + (allPhones.camera_score);
  if(total_score >= 17 ){
  allPhones.rating = 'A';
}else if(15 <=total_score && total_score < 17){
  allPhones.rating = 'B';
}else if(14 <= total_score && total_score < 15){
  allPhones.rating = 'C';
}else if(total_score < 14){
  allPhones.rating = 'D';
}
return;
}



void processInputFile(ifstream & fin, phone allPhones[], const int allPhonessize){
for(int i = 0; i <= allPhonessize-1; i++){
  fin >> allPhones[i].phone_model;
  fin >> allPhones[i].cpu_score;
  fin >> allPhones[i].gpu_score;
  fin >> allPhones[i].camera_score;
  computeRating(allPhones[i]);
}
  return;

}

void display(ofstream & fout, const phone & allPhones){
  fout << "Phone Model: " << allPhones.phone_model << ", CPU score: " << allPhones.cpu_score << ", GPU score: " << allPhones.gpu_score << ", RATING: " << allPhones.rating << endl;
}
