// Programmer: <John Bramer>
// Student ID: <jdb5kh>
// Section: <307>
// Date: <03/23/2022>
// File: lab9.cpp
#include "helper.h"
#include <iostream>
#include <string>
#include <fstream>
using namespace std; 


int main()
{
const int allPhonessize = 4;
phone allPhones[allPhonessize];
ifstream fin;
string output;
string input;
ofstream fout;
  

do{
  cout << "Enter the input file name: " << endl;
  cin >> input;
}while(input != "input.dat");
fin.open(input);
processInputFile(fin, allPhones, allPhonessize);

fin.close();
do{
  cout << "Enter the Outputt file name: " << endl;
  cin >> output;
}while(output != "output.txt");




fout.open(output);
for(int b = 0; b<= 3; b++){
display(fout, allPhones[b]);


}
fout.close();
return 0;
}

