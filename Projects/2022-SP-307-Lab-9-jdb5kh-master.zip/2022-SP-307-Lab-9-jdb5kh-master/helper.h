#include <iostream>
#include <fstream>
#include <string>
#ifndef Helper_h
#define Helper_h
using namespace std;
struct phone{
    string phone_model;
    double cpu_score;
    double gpu_score;
    double camera_score;
    char rating;
};


void computeRating(phone & allPhones);

void processInputFile(ifstream &fin, phone allPhones[],int allPhonessize);

void display(ofstream & fout, const phone & allPhones);

#endif
