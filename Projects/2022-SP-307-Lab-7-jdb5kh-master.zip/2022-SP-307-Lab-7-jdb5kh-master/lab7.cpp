// Programmer: <John Bramer> 
// Student ID: <jdb5kh> 
// Section: <307> 
// Date: <3/9/2022> 
// File: lab7.cpp 
// Purpose: Description of the function of the program 
#include <iostream>
#include <string>
using namespace std;

struct student{
    string student_name;
  int student_age;
  int student_ID;
  int student_score;
};

int main()
{
    student Theclass[4];
    float average;
 

  
  for(int i = 0; i <= 3; i++){
      cout << "Enter the details for student " << i << endl;
      cout << "Name: ";
      cin >> Theclass[i].student_name;;
      cout << "Age: ";
      cin >> Theclass[i].student_age;
      cout << "Student ID: " ;
      cin >> Theclass[i].student_ID;
      cout << "Score: " ;
      cin >> Theclass[i].student_score;
  
}
    cout << "Name\t Age\t Student ID\t Score" << endl;
    
    for(int k =0; k<= 3; k++){
     cout << Theclass[k].student_name << "\t";
     cout << Theclass[k].student_age << "\t";
     cout << Theclass[k].student_ID << "\t";
     cout << Theclass[k].student_score << endl;
     cout << "\n";
     average += Theclass[k].student_score;
    }
    cout << "Class average is " <<average/4 << endl;
}
