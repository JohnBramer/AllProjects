// Programmer: <John Bramer>
// Student ID: <jdb5kh>
// Section: <307>
// Date: <02/23/2022>
// File: lab6.cpp
// Purpose: To take the volume of a cylinder, and area of a rectanlge. Using default parameters and user inputted ones.


#include <iostream>
#include <string>
#include "header.h"
using namespace std;

int main()
{
    double length = 0;
    double width = 0;
    double radius = 0;
    double height = 0;


    cout << "Please enter length of your rectangle" << endl;
    cin >> length;
    cout << "Please enter the width of your rectangle" << endl;
    cin >> width;
    cout << "The area of your rectangle is " << computeArea(length, width) << endl;
    cout << "The default volume is " << computeVolume() << endl;
    cout << "Now try with your doubles, enter a radius" << endl;
    cin >> radius;
    cout << "The area of your cylinder is now " << computeVolume(radius) << endl;
    cout << "Now try with both of your measurements" << endl;
    cout << "Enter a radius, then a height" << endl;
    cin >> radius;
    cin >> height;
    cout << "The area of your cylinder is now " << computeVolume(radius, height) << endl;

}
