#include <string>
#ifndef HEADER_H
#define HEADER_H
#include <iostream>

using namespace std;

//des: computes the are of a rectangle
//pre: both length and width must be a double
//post: the area of the rectangle
double computeArea(const double length, const double width);
//des: computes the volume of a cylinder
//pre: both radius and height must be a double
//post the volume of the cylinder
double computeVolume(const double radius = 5.0, const double height = 10.0);
#endif
