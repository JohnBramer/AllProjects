// #include "Header.h" //[grader] Causes code to not compile
#include "header.h"
#include <iostream>
using namespace std;


bool leave(bool decision) {
    if (decision == false) {
        return false;
    }
    else {
        return true;
    }
}

void greeting() {
    cout << "Welcome to Are you Smarter than a Comp Sci! Ready to play?" << endl;
}

void answerRandomly() {
    int rand_num = (rand() % (4)) + 1;
    cout << "You thought of the number " << rand_num << ". What is your answer?" << endl;
    return;

}

void printQuestion(int questionNumber, const int ONE, const int TWO, const int THREE, const int FOUR, const int FIVE, const int SIX, const int SEVEN, const int EIGHT, const int NINE, const int TEN) {
    if (questionNumber == ONE) {
        cout << "Question 1 Which of these is not a numeric data type?" << endl;
        cout << "1 - integer" << endl;
        cout << "2 - double" << endl;
        cout << "3 - boolean" << endl;
        cout << "4 - float" << endl;
    }
    else if (questionNumber == TWO) {
        cout << "Question 2 Which of the following is a reserved c++ keyword?" << endl;
        cout << "1 - buddy" << endl;
        cout << "2 - friend" << endl;
        cout << "3 - pal" << endl;
        cout << "4 - homeslice" << endl;
    }
    else if (questionNumber == THREE) {
        cout << "Question 3 What does the & symbol mean in C++?" << endl;
        cout << "1 - address of" << endl;
        cout << "2 - and" << endl;
        cout << "3 - not" << endl;
        cout << "4 - value of" << endl;
    }
    else if (questionNumber == FOUR) {
        cout << "Question 4 You do not need to document your functions in CS1570" << endl;
        cout << "1 - true" << endl;
        cout << "2 - false" << endl;
        cout << "3 - sometimes" << endl;
        cout << "4 - I don\'t know" << endl;
    }
    else if (questionNumber == FIVE) {
        cout << "Question 5 What is “OOP”?" << endl;
        cout << "1 - Only Once Programming" << endl;
        cout << "2 - Object Oriented Programming" << endl;
        cout << "3 - What I say when I stub my toe" << endl;
        cout << "4 - Ope, oh peanuts." << endl;
    }
    else if (questionNumber == SIX) {
        cout << "Question 6: How many significant digits can a float have?" << endl;
        cout << "1 - 9" << endl;
        cout << "2 - 8" << endl;
        cout << "3 - 7" << endl;
        cout << "4 - 6" << endl;
    }
    else if (questionNumber == SEVEN) {
        cout << "Question 7: If C is 3, then C++ is:" << endl;
        cout << "1 - An object oriented programming language" << endl;
        cout << "2 - 4" << endl;
        cout << "3 - Amazing" << endl;
        cout << "4 - All of the above" << endl;
    }
    else if (questionNumber == EIGHT) {
        cout << "Question 8: What is the maximum value of a signed integer in C++?" << endl;
        cout << "1 - 81" << endl;
        cout << "2 - 2147483647" << endl;
        cout << "3 - 11" << endl;
        cout << "4 - -12" << endl;
    }
    else if (questionNumber == NINE) {
        cout << "Question 9: What does == do in C++?" << endl;
        cout << "1 - Sets the left variable equal to the right value" << endl;
        cout << "2 - Checks the validity of a data type in C++" << endl;
        cout << "3 - Checks if 2 values are equal to each other" << endl;
        cout << "4 - All of the above" << endl;
    }
    else if (questionNumber == TEN) {
        cout << "Question 10: Can you lose money in this game show?" << endl;
        cout << "1 - Yes" << endl;
        cout << "2 - No" << endl;
        cout << "3 - Don’t pick this one" << endl;
        cout << "4 - Don’t pick this one either" << endl;
    }
}

bool isCorrect(int questionNumber, string userAnswer, const int ONE, const int TWO, const int THREE, const int FOUR, const int FIVE, const int SIX, const int SEVEN, const int EIGHT, const int NINE, const int TEN){
    if (questionNumber == ONE && userAnswer == "3") {
        return true;
    }else if (questionNumber == TWO && userAnswer == "2") {
        return true;
    }else if (questionNumber == THREE && userAnswer == "1") {
        return true;
    }else if (questionNumber == FOUR && userAnswer == "2") {
        return true;
    }else if (questionNumber == FIVE && userAnswer == "2") {
        return true;
    }else if (questionNumber == SIX && userAnswer == "4") {
        return true;
    }else if (questionNumber == SEVEN && userAnswer == "4") {
        return true;
    }else if (questionNumber == EIGHT && userAnswer == "2") {
        return true;
    }else if (questionNumber == NINE && userAnswer == "3") {
        return true;
    }else if (questionNumber == TEN && userAnswer == "1") {
        return true;
    }
    else {
        return false;
    }
}

void lifeLine(int questionNumber, const int ONE, const int TWO, const int THREE, const int FOUR, const int FIVE, const int SIX, const int SEVEN, const int EIGHT, const int NINE, const int TEN) {
    int randomnum = (rand() % TEN) + ONE;
    if (randomnum <= EIGHT) {
        if (questionNumber == ONE) {
            cout << "Your friend said the answer is 3. What is your answer?" << endl;
        }
        else if (questionNumber == TWO) {
            cout << "Your friend said the answer is 2. What is your answer?" << endl;
        }
        else if (questionNumber == THREE) {
            cout << "Your friend said the answer is 1. What is your answer?" << endl;
        }
        else if (questionNumber == FOUR) {
            cout << "Your friend said the answer is 2. What is your answer?" << endl;
        }
        else if (questionNumber == FIVE) {
            cout << "Your friend said the answer is 2. What is your answer?" << endl;
        }
        else if (questionNumber == SIX) {
            cout << "Your friend said the answer is 4. What is your answer?" << endl;
        }
        else if (questionNumber == SEVEN) {
            cout << "Your friend said the answer is 4. What is your answer?" << endl;
        }
        else if (questionNumber == EIGHT) {
            cout << "Your friend said the answer is 2. What is your answer?" << endl;
        }
        else if (questionNumber == NINE) {
            cout << "Your friend said the answer is 3. What is your answer?" << endl;
        }
        else if (questionNumber == TEN) {
            cout << "Your friend said the answer is 1. What is your answer?" << endl;
        }
    }
    else {
        cout << "Your friend said the answer is " << randomnum << ". What is your answer?" << endl;
    }
}

void exitMessage(string winLoseOrLeave, int balance) {
	if(winLoseOrLeave == "leave"){
		cout << "The game is over, you left" << endl;
	}else{
		cout << "The game is over, you " << winLoseOrLeave << endl;
	}	
    cout << "Your current balance is $" << balance << endl;
}
