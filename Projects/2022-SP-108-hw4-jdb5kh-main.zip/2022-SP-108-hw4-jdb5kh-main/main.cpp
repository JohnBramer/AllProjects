// Programmer: John Bramer
// Student ID: <jdb5kh>
// Section: <108>
// Date: 4/10/2021.
// File: main.cpp
// Assignment: HW4
// Purpose: This is a trivia comp sci game

// #include "Header.h" //[grader] Causes code to not compile
#include "header.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{
    (srand(11));
    bool decision = true;
    int questionNumber = 1;
    string userAnswer;
    int balance = 100;
    int lifelineCount = 1;
    int lifeCount = 3;
    bool isCorrect2;
	const int ZERO = 0;
	const int ONE = 1;
	const int TWO = 2;
	const int THREE = 3;
	const int FOUR = 4;
	const int FIVE = 5;
	const int SIX = 6;
	const int SEVEN = 7;
	const int EIGHT = 8;
	const int NINE = 9;
	const int TEN = 10;
	 
	
	
	
	
    string winLoseOrLeave;

    greeting();

    while (leave(decision) && lifeCount > ZERO && questionNumber <= TEN){
        printQuestion(questionNumber, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN);


        do {
            do {
                cin >> userAnswer;
                if (userAnswer != "1" && userAnswer != "2" && userAnswer != "3" && userAnswer != "4" && userAnswer != "random" && userAnswer != "lifeline" && userAnswer != "leave") {
                    cout << "Please enter a valid option (1, 2, 3, 4, random, lifeline, or leave)" << endl;
                }
            } while (userAnswer != "1" && userAnswer != "2" && userAnswer != "3" && userAnswer != "4" && userAnswer != "random" && userAnswer != "lifeline" && userAnswer != "leave");


            if (userAnswer == "lifeline") {
                if (lifelineCount <= THREE) {
                    lifeLine(questionNumber, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN);
                    lifelineCount = lifelineCount + ONE;

                }
                else {
                    cout << "You ran out of lifelines! Pick another option" << endl;
                }
            }
            else if (userAnswer == "random") {
                answerRandomly();
            }


        } while(userAnswer != "1" && userAnswer != "2" && userAnswer != "3" && userAnswer != "4" && userAnswer != "leave");
            

        if (userAnswer == "1" or userAnswer == "2" or userAnswer == "3" or userAnswer == "4") {
            isCorrect(questionNumber, userAnswer, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN);

            if (isCorrect(questionNumber, userAnswer, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN) == true) {

                cout << "Correct" << endl;
                //isCorrect2 = true;
                
                updateMoney(balance, isCorrect2 = true); 
            
                
            }
            else {
                lifeCount = lifeCount - ONE;
                cout << "Incorrect" << " You have " << lifeCount << " lives remaining" << endl;
                
                updateMoney(balance, isCorrect2 = false); 
             
            }
        }
        else if (userAnswer == "leave") {
            leave(decision = false);
            winLoseOrLeave = "leave";
        }

        questionNumber = questionNumber + ONE;
       
       
    
    }
	

    

    if (lifeCount == ZERO && winLoseOrLeave != "leave") {
        cout << "It looks like you ran out of lives, better luck next time" << endl;
		winLoseOrLeave = "lost";
	}else if(winLoseOrLeave == "leave"){
		cout << "player left" << endl;
	
    }else {
        winLoseOrLeave = "won";
    }

    


 exitMessage(winLoseOrLeave, balance);
}



