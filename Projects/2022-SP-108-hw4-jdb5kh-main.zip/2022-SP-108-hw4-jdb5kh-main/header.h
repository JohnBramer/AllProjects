#ifndef HEADER_H
#define HEADER_H
#include <string>
#include <iostream>
using namespace std;

//des: This function greets the user.
//pre: none
//post: A greeting is printed
void greeting();
//des: This function exits the game
//pre: none
//post: The user is left from the game when ever called
bool leave(bool decision);
//des: This function helps the user pick an answer. 
//pre: none
//post: prints a random number from 1-4.
void answerRandomly();
//des: This function prints a new answer
//pre: The question number must be from 1-10
//post: This prints the next question, and will loop if all the questions will need to be answered.
void printQuestion(int questionNumber, const int ONE, const int TWO, const int THREE, const int FOUR, const int FIVE, const int SIX, const int SEVEN, const int EIGHT, const int NINE, const int TEN);
//des: This function check to see if the user answered correctly
//pre: The user must have answer with an option of 1-4
//post: This will return a bool value if the user got an answer correct (true)
bool isCorrect(int questionNumber, string userAnswer, const int ONE, const int TWO, const int THREE, const int FOUR, const int FIVE, const int SIX, const int SEVEN, const int EIGHT, const int NINE, const int TEN);
//des: This function is a lifeline for the user playing the game
//pre: can only be called 3 times
//post: There is an 80% chance this function will print the correct answer.
void lifeLine(int questionNumber, const int ONE, const int TWO, const int THREE, const int FOUR, const int FIVE, const int SIX, const int SEVEN, const int EIGHT, const int NINE, const int TEN);
//des: This function prints the total game summary.
//pre: none
//post: This function prints what the user did in order to exit the game, and the total balance they won/lost
void exitMessage(string winLoseOrLeave, int balance);
//des: This function calautes the new user balance after a question is answered.
//pre: A valid question must be answered (1-4)
//post: The balance is multiplied by 2 if an answer is correct, and 100 is subtracted if an answer is incorrect.
template <typename T>
T updateMoney(T& balance, bool isCorrect2) {
	if (isCorrect2 == false) {
		 balance = balance - 100;
	}
	if (isCorrect2 == true) {
		balance = balance * 2;
	}
	
	return balance;
}

#endif // !HEADER_H

