#include <iostream>
#include <string>
#include "Neighbor.h"
#include "NewHomeowner.h"
#include <cstdlib>
using namespace std;

void initalizeNeighbor(Neighbor individuals[]) {

	for (int i = 0; i <= 5; i++) {
		individuals[i].neighbor_total_acres = (rand() % (32)) + 19;
		individuals[i].neighbor_garages = individuals[i].neighbor_total_acres / 10;
		individuals[i].neighbor_ID = i + 1;
		if (((rand() % (2)) + 1) == 1) {
			individuals[i].goodorbad = true;
			individuals[i].activity = true;
		}
		else {
			individuals[i].goodorbad = false;
			individuals[i].activity = false;
		}

	}
}



void requestAssistance(NewHomeowner& theNewHomeowner, Neighbor& aGoodNeighbor) {
	int tempnum = theNewHomeowner.home_garages;
	
	if (theNewHomeowner.home_garages < aGoodNeighbor.neighbor_garages) {
		if (((rand() % (10)) + 1) <= 8) {
			aGoodNeighbor.neighbor_garages = aGoodNeighbor.neighbor_garages - 1;
			theNewHomeowner.home_garages = theNewHomeowner.home_garages + 1;
			cout << "Good Neighbor ID: " << aGoodNeighbor.neighbor_ID << endl;
			cout << "You have taken 1 garage from your friendly good neighbor" << endl;
			cout << "You now have " << theNewHomeowner.home_garages << " garages" << endl;
			cout << "Change: " << tempnum - theNewHomeowner.home_garages;
		}
		else {
			cout << "Good Neighbor ID: " << aGoodNeighbor.neighbor_ID << endl;
			cout << "it looks like you where unlucky better luck next round" << endl;
			cout << "You now have " << theNewHomeowner.home_garages << " garages" << endl;
			cout << "Change: " << tempnum - theNewHomeowner.home_garages;
		}
	}
	else {
		if (((rand() % (10)) + 1) <= 3) {
			aGoodNeighbor.neighbor_garages = aGoodNeighbor.neighbor_garages - 1;
			theNewHomeowner.home_garages = theNewHomeowner.home_garages + 1;
			cout << "Good Neighbor ID: " << aGoodNeighbor.neighbor_ID << endl;
			cout << "You have taken 1 garage from your friendly good neighbor" << endl;
			cout << "You now have " << theNewHomeowner.home_garages << " garages" << endl;
			cout << "Change: " << tempnum - theNewHomeowner.home_garages << endl;
		}
		else {
			cout << "Good Neighbor ID: " << aGoodNeighbor.neighbor_ID << endl;
			cout << "it looks like you where unlucky better luck next round" << endl;
			cout << "You now have " << theNewHomeowner.home_garages << " garages" << endl;
			cout << "Change: " << tempnum - theNewHomeowner.home_garages << endl;
		}

	}

}

void defendHomeland(NewHomeowner& theNewHomeowner, Neighbor& aBadNeighbor, int& stolenLand) {
	int temp = 0;
	int temp2 = theNewHomeowner.home_garages;
	if (theNewHomeowner.home_garages < aBadNeighbor.neighbor_garages) {
		if (((rand() % (100)) + 1) <= 53) {
			temp = abs(theNewHomeowner.home_garages - aBadNeighbor.neighbor_garages);
			aBadNeighbor.neighbor_garages += 1;
				theNewHomeowner.home_garages -= 1;
			stolenLand += temp;
			cout << "Bad Neighbor ID: " << aBadNeighbor.neighbor_ID << endl;
			cout << "Your bad neighbor took "<< temp << " garages from you" << endl;
			cout << "You now have " << theNewHomeowner.home_garages << " garages" << endl;
			cout << "Change: " << temp2 - theNewHomeowner.home_garages << endl;

			if (((rand() % (100) + 1)) <= 46) {
				aBadNeighbor.neighbor_garages += 1;
				stolenLand += 1;
				cout << "Bad Neighbor ID: " << aBadNeighbor.neighbor_ID << endl;
				cout << "The bad neighbor also got lucky and built an extra garage" << endl;
				cout << "You now have " << theNewHomeowner.home_garages << " garages" << endl;
				cout << "Change: " << temp2 - theNewHomeowner.home_garages << endl;

			}
		}
	}
	else {
		if (((rand() % (80)) + 1) % 2 == 0 && stolenLand > 0){
			if (((rand() % (100) + 1)) <= 73) {
				theNewHomeowner.home_garages += stolenLand / 2;
				aBadNeighbor.neighbor_garages -= stolenLand;
				cout << "Home defence successful!" << endl;
				cout << "Bad Neighbor ID: " << aBadNeighbor.neighbor_ID << endl;
				cout << "You where unlucky and lost half of your garages" << endl;
				cout << "You now have " << theNewHomeowner.home_garages << endl;
				cout << "Change: " << temp2 - theNewHomeowner.home_garages << endl;
			}
			else {
				cout << "Home defence successful!" << endl;
				cout << "Bad Neighbor ID: " << aBadNeighbor.neighbor_ID << endl;
				theNewHomeowner.home_garages += stolenLand;
				aBadNeighbor.neighbor_garages -= stolenLand;
				cout << "You where unlucky and then got lucky... You stole some land back" << endl;
				cout << "You now have " << theNewHomeowner.home_garages << " garages" << endl;
				cout << "Change: " << temp2 - theNewHomeowner.home_garages << endl;
			}
}
	}
	if (stolenLand == 0) {
		aBadNeighbor.activity = false;
	}
}



bool goodorBadNeighbor(Neighbor individuals[]) {
	bool returnval = false;
	for (int i = 0; i <= 5; i++) {
		if (individuals[i].goodorbad == 0) {
			returnval = true;
		}
	}
	return returnval;
}
	
