
#include <iostream>
#include <string>
#include "NewHomeowner.h"
#include "Neighbor.h"
#include "functions.h"

using namespace std;

int main()
{
	srand(327);
	int stolenLand[6] = { 0,0,0,0,0,0 };
	int initialgarages[6];
	int round_count = 1;
	Neighbor individuals[6];
	NewHomeowner theNewHomeowner;
	initalizeNeighbor(individuals);


	

	for (int p = 0; p <= 5; p++) {
		initialgarages[p] = individuals[p].neighbor_garages;
	}

	cout << "Welcome to the Home Defender Gamee" << endl;
	cout << "Please enter a Home address" << endl;
	getline(cin, theNewHomeowner.address);
	cout << "Please enter a Home name" << endl;
	getline(cin, theNewHomeowner.home_name);
	cout << "Please enter an amount of acres you want to begin with" << endl;
	cin >> theNewHomeowner.home_total_acres;
	cout << "Lastly, please enter the amount of garages you want to start with" << endl;
	cin >> theNewHomeowner.home_garages;
	int initial_garages = theNewHomeowner.home_garages;
	


	
	cout << "**********************************" << endl;
	while (goodorBadNeighbor(individuals) && round_count < 11) {
		cout << "ROUND " << round_count << ":" << endl;
		for (int i = 0; i <= 5; i++) {

			if (individuals[i].goodorbad == true) {
				requestAssistance(theNewHomeowner, individuals[i]);

			}
			else {
				defendHomeland(theNewHomeowner, individuals[i], stolenLand[i]);

			}
		


			
		}


		for (int g = 0; g <= 5; g++) {
			if (individuals[g].neighbor_garages == 0) {
				individuals[g].activity = true;
				individuals[g].goodorbad = true;
			}
		}
		round_count = round_count + 1;


	

	}
	cout << "**********************************" << endl;
	cout << "Summary of the game" << endl;
	cout << "Homeowner: " << theNewHomeowner.home_name << endl;
	cout << "Home Address: " << theNewHomeowner.address << endl;
	cout << "Initial Number of Acres of Land Owned: " << theNewHomeowner.home_total_acres << endl;
	cout << "Final Number of Acres of Land Owned: " << theNewHomeowner.home_total_acres << endl;
	cout << "Initial Number of garages Owned: " << initial_garages << endl;
	cout << "Final Number of garages Owned: " << theNewHomeowner.home_garages << endl;
	
	for (int b = 0; b <= 5; b++) {
		cout << "Neighbor ID #: " << individuals[b].neighbor_ID << endl;
		cout << "Acres of Land Owned: " << individuals[b].neighbor_total_acres << endl;
		cout << "Acres of Land Stolen: " << stolenLand[b] << endl;
		cout << "Initial Number of Garages Owned: " << initialgarages[b] << endl;
		cout << "Final Number of Garages Owned: " << individuals[b].neighbor_garages << endl;
		if (individuals[b].goodorbad == 1) {
			cout << "Likable? GOOD!" << endl;
		}
		else {
			cout << "Likable? BAD!" << endl;
		}
		if (individuals[b].activity == 1) {
			cout << "Status: ACTIVE" << endl;
		}
		else {
			cout << "Status: INACTIVE" << endl;
		}

	}
}

