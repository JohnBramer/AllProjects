#ifndef NEWHOMEOWNER_H
#define NEWHOMEOWNER_H
#include <iostream>
#include <string>
using namespace std;

struct NewHomeowner {
	string address;
	string home_name;
	int home_total_acres;
	int home_garages;

};








#endif // !HEADER_H
