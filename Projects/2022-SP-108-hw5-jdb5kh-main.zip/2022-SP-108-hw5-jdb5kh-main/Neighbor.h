#ifndef NEIGHBOR_H
#define NEIGHBOR_H
#include <iostream>
#include <string>
#include "NewHomeowner.h"
using namespace std;


struct Neighbor {
	int neighbor_ID;
	float neighbor_total_acres;
	int neighbor_garages;
	bool goodorbad;
	bool activity;
};






#endif
