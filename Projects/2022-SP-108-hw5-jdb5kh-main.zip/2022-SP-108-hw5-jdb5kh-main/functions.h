#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <iostream>
#include <string>
using namespace std;

//des: This function initalizes our neighbors with random values
//pre: none
//post: 6 neighbors are created with random attributes
void initalizeNeighbor(Neighbor individuals[]);
//des: This function requests assistance, if lucky the home owner can get some free garages from the good neighbors
//pre: the game must have already started, and a good nighbor must be passed in the function
//post: depending on randomniss, the new home owner may or may not get more garages
void requestAssistance(NewHomeowner& theNewHomeowner, Neighbor& aGoodNeighbor);
//des: This function defends homeland, if unlucky the bad neighbors will take some land from the homeowner.
//pre: the game must have already started, and a bad neighbor must be passed in the function.
//post: depending on randomniss, the new home owner may or may not lose garages/ the bad neighbor may or may not get garages.
void defendHomeland(NewHomeowner& theNewHomeowner, Neighbor& aBadNeighbor, int& stolenLand);
//des: This function tells our while loop if there are still bad neighbors to be looked at.
//pre: the neighbors must have been initalized
//post: This function will return true if bad neighbors are still in our array.
bool goodorBadNeighbor(Neighbor individuals[]);





#endif
