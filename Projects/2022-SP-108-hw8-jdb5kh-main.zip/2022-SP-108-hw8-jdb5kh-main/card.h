#ifndef CARD_H
#define CARD_H
#include <iostream>
#include <string>

using namespace std;

class Card{
	public:
		//This is a default constructor for creating a card class
		Card();
		//This is a parameterized constructor for creating a card class
		Card(char num, char suit);
		//Des: This function converts a chard to an integer.
		//Pre: A card class must be used
		//Post: an integer returing the value for the card
		int charToNum() const;
		//Des: This function returns true if a card has been destroyed
		//Pre: none
		//Post: boolean true or false
		bool isDestroyed() const;
		//Des: This function adds two card Objects
		//Pre: none
		//Post: an integer representing the value for two card objects added
		int operator + (Card & card) const;
		//Des: This function returns true if card a is greater than card b
		//Pre: none
		//Post: true or false boolean
		bool operator > (Card & card) const;
		//Des: This function returns true if card a is less than card b
		//Pre: none
		//Post: boolean true or false
		bool operator < (Card & card) const;
		//Des: This function returns true if two cards equal each other
		//Pre: none
		//Post: True or false
		bool operator == (Card & card) const;
		//Des: Similarly this function returns false if two cards don't equal each other
		//Pre: none
		//Post: true or false
		bool operator != (Card & card) const;
		//Des: This function destroys a card objects
		//Pre: none
		//Post: A boolean var is switched true when this function is called on that class
		void operator ~ ();
		//Des: This function outputs card objects
		//Pre: none
		//Post: An output of our card character and suit
		friend ostream & operator << (ostream &out, Card & card);
	private:
		char card_char;
		char card_suit;
		bool destroyed;
	
	
	
	
};










#endif	
