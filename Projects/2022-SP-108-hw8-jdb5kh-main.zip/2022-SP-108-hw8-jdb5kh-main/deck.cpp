#include <iostream>
#include <string>
#include "card.h"
#include "Deck.h"


using namespace std;

Deck::Deck(){
	cardsInDeck = 52;
	cards[0] = Card('A', 'S');
	cards[1] = Card('2', 'S');
	cards[2] = Card('3', 'S');
	cards[3] = Card('4', 'S');
	cards[4] = Card('5', 'S');
	cards[5] = Card('6', 'S');
	cards[6] = Card('7', 'S');
	cards[7] = Card('8', 'S');
	cards[8] = Card('9', 'S');
	cards[9] = Card('X', 'S');
	cards[10] = Card('J', 'S');
	cards[11] = Card('Q', 'S');
	cards[12] = Card('K', 'S');
	
	cards[13] = Card('A', 'C');
	cards[14] = Card('2', 'C');
	cards[15] = Card('3', 'C');
	cards[16] = Card('4', 'C');
	cards[17] = Card('5', 'C');
	cards[18] = Card('6', 'C');
	cards[19] = Card('7', 'C');
	cards[20] = Card('8', 'C');
	cards[21] = Card('9', 'C');
	cards[22] = Card('X', 'C');
	cards[23] = Card('J', 'C');
	cards[24] = Card('Q', 'C');
	cards[25] = Card('K', 'C');
	
	cards[26] = Card('A', 'D');
	cards[27] = Card('2', 'D');
	cards[28] = Card('3', 'D');
	cards[29] = Card('4', 'D');
	cards[30] = Card('5', 'D');
	cards[31] = Card('6', 'S');
	cards[32] = Card('7', 'D');
	cards[33] = Card('8', 'D');
	cards[34] = Card('9', 'D');
	cards[35] = Card('X', 'D');
	cards[36] = Card('J', 'D');
	cards[37] = Card('Q', 'D');
	cards[38] = Card('K', 'D');
	
	cards[39] = Card('A', 'H');
	cards[40] = Card('2', 'H');
	cards[41] = Card('3', 'H');
	cards[42] = Card('4', 'H');
	cards[43] = Card('5', 'H');
	cards[44] = Card('6', 'H');
	cards[45] = Card('7', 'H');
	cards[46] = Card('8', 'H');
	cards[47] = Card('9', 'H');
	cards[48] = Card('X', 'H');
	cards[49] = Card('J', 'H');
	cards[50] = Card('Q', 'H');
	cards[51] = Card('K', 'H');
}	


Deck::Deck(Card temp_cards[], int size){
	for(int i = 0; i<size; i++){
		this->cards[i] = temp_cards[i];
		//cout << this->cards[i] << endl;
	}		
}


void Deck::shuffle(){
	srand(469);
	Card temp_card;
    for (int i=0; i<52 ;i++){
        int x = rand() % 52;
		temp_card = cards[i];
		
		cards[i] = cards[x];
		cards[x] = temp_card;
	
    }

} 

Card &Deck::getCard(int index){
	return cards[index];
}
	
	
void Deck::setCount(int size){
	cardsInDeck = 0;
	for(int i = 0; i<size; i++){
		if(cards[i].isDestroyed() == false){
			this->cardsInDeck++;
		}
	}
}

int Deck::getCardCount(){
		return (this->cardsInDeck);
}

int Deck::findSpot(){
	for(int i = 0; i<52; i++){
		if(cards[i].isDestroyed() == true){
			return i;
		}
	}
		return 0;
}
	