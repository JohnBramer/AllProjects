#ifndef DECK_H
#define DECK_H
#include <iostream>
#include <string>

using namespace std;

class Deck{
	
	public:
		//This is a default constructor for creating a Deck class
		Deck();
		//This is a parameterized constructor for creating a Deck class
		Deck(Card temp_cards[], int size);
		//Des: This function sets the count of active cards in our deck
		//Pre: none
		//Post: The card count is updated with active cards
		void setCount(int size);
		//Des: This function shuffles our deck of cards
		//Pre: none
		//Post: Our card objects in deck will be randomized
		void shuffle();
		//Des: This function returns our count of cards in deck
		//Pre: none
		//Post: An int representing the amount of active cards still in a deck
		int getCardCount();
		//Des: This function returns a card in our deck
		//Pre: valid index location
		//Post: The card object in our deck
		Card &getCard(int index);
		//Des: This function finds the next spot for an overtaken card to populate 
		//Pre: none
		//Post: an integer returning represents the location for a new card to populate
		int findSpot();
	private:
		Card cards[52];
		int cardsInDeck;
	
	
	
	
	
	
	
};

#endif