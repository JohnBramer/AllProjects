// Programmer: John Bramer
// Date: 4/25/2021.
// File: Card Wars.cpp
// Assignment: HW8
// Purpose: This is a card game of war
#include <iostream>
#include <string>
#include "card.h"
#include "Deck.h"

using namespace std;

int main(){
	int temp_num = 0;
	int temp_num_two = 0;
	bool start = true;
	string player_name_one;
	string player_name_two;
	
	Deck deck;
	deck.shuffle();
	
	
	Card orgin_cards[26];
	Card orgin_cards_two[26];
	
	for(int k = 0; k<26; k++){
		orgin_cards[k] = deck.getCard(k); 
	}
	
	for(int h = 26; h<52; h++){
		orgin_cards_two[h-26] = deck.getCard(h);
	}	
	Deck player_one(orgin_cards, 26);
	Deck player_two(orgin_cards_two, 26); 
	player_one.setCount(26);
	player_two.setCount(26);
	
	cout << "This is war!" << endl;
	cout << "Input defender name" << endl;
	cin >> player_name_one;
	cout << "Input attacker name: " << endl;
	cin >> player_name_two;
	
	
while(start){

	for(int i = 0; i<26; i++){	
		while(player_one.getCard(temp_num).isDestroyed() == true){
			temp_num++;
		}
		
		while(player_two.getCard(temp_num_two).isDestroyed() == true){
			temp_num_two++;
		}
		
		if (player_one.getCard(i+temp_num) > player_two.getCard(i+temp_num_two)){
			player_one.getCard(player_one.findSpot()) = player_two.getCard(i+temp_num_two);
			~player_two.getCard(i+temp_num_two);
			cout << player_one.getCard(i+temp_num) << "-" <<player_two.getCard(i+temp_num_two) << " : "<<player_name_one << " wins" << endl;
		}else if(player_one.getCard(i+temp_num) < player_two.getCard(i+temp_num_two)){
			player_one.getCard(player_two.findSpot()) = player_one.getCard(i+temp_num);
			~player_one.getCard(i+temp_num_two);
			cout << player_one.getCard(i+temp_num) << "-" <<player_two.getCard(i+temp_num_two) << " : " <<player_name_two << " wins" << endl;
		}
		
		if(player_one.getCard(i+temp_num) + player_two.getCard(i+temp_num_two) == 11){
			~player_one.getCard(i+temp_num);
			~player_two.getCard(i+temp_num_two);
			cout << player_one.getCard(i+temp_num) << "-" <<player_two.getCard(i+temp_num_two) << ": Both cards destroyed" << endl;
		}
		
		if(player_one.getCard(i+temp_num) == player_two.getCard(i+temp_num_two)){
			~player_one.getCard(i+temp_num);
			~player_two.getCard(i+temp_num_two);
			cout << player_one.getCard(i+temp_num) << "-" <<player_two.getCard(i+temp_num_two) << ": Both cards destroyed" << endl;
			
		}
		
		player_one.setCount(26);
		player_two.setCount(26);	
		
		if(player_one.getCardCount() <= 10){
			start = false;
		}
		if(player_two.getCardCount() <= 10){
			start = false;
		}
			
		temp_num = 0;
		temp_num_two = 0;
}
}

		if(player_one.getCardCount() <= 10){
			cout << player_name_two << " Wins the game" << endl;
		}
		if(player_two.getCardCount() <= 10){
			cout << player_name_one << " Wins the game" << endl;
		}
		
		
		
		return 0;
		
}