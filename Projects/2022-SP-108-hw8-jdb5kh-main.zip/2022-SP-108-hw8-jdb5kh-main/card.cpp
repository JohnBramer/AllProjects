#include <iostream>
#include <string>
#include "card.h"
#include "Deck.h"


using namespace std;

Card::Card(){
	this->destroyed = true;
	this->card_char = '0';
	this->card_suit = '0';
	
}


Card::Card(char num, char suit){
	card_char = num;
	card_suit = suit;
	
}



int Card::operator + (Card & card) const{
	return (card.charToNum() + this->charToNum());
}

bool Card::operator > (Card & card) const{
	if(this->card_suit != card.card_suit){
		if(this->charToNum() > card.charToNum()){
			return true;
		}else{
			return false;
		}
	}else{
		if(this->charToNum() < card.charToNum()){
			return true;
		}else{
			return false;
		}
	
	}
}


bool Card::operator < (Card & card) const{
	if(this->card_suit != card.card_suit){
		if(this->charToNum() < card.charToNum()){
			return true;
		}else{
			return false;
		}
	}else{
		if(this->charToNum() > card.charToNum()){
			return true;
		}else{
			return false;
		}
	
	}
}

bool Card::operator == (Card & card) const{
	if(this->charToNum() == card.charToNum()){
		return true;
	}else{
		return false;
	}
}

bool Card::operator != (Card & card) const{
	if(this->charToNum() == card.charToNum()){
		return false;
	}else{
		return true;
	}		
}

void Card::operator ~(){
	destroyed = !destroyed;
}

bool Card::isDestroyed() const{
	if(this->destroyed == true){
		return true;
	}else{
		return false;
	}
}


ostream &operator << (ostream &out, Card & card){
	out << card.card_char << card.card_suit;
	return out;
}


int Card::charToNum() const{
	if(this->card_char == 'J' or this->card_char == 'Q' or this->card_char == 'K'){
		return 10;
	}else if(this->card_char == '2'){
		return 2;
	}else if(this->card_char == '3'){
		return 3;
	}else if(this->card_char == '4'){
		return 4;
	}else if(this->card_char == '5'){
		return 5;
	}else if(this->card_char == '6'){
		return 6;
	}else if(this->card_char == '7'){
		return 7;
	}else if(this->card_char == '8'){
		return 8;
	}else if(this->card_char == '9'){
		return 9;	
	}else if(this->card_char == 'X'){
		return 10;
	}else{
		return 0;
	}
	
}


		




	
