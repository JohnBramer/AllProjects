#ifndef HEADER1_H
#define HEADER1_H
#include <iostream>
#include <string>
using namespace std;


bool isEdgecord(int airdrop[], const int LENGTH, const int TILE_BLANK);

void infest_mid(string grid[10][10], int xval, int yval, const int TILE_BLANK, const int TILE_BEE, const int TILE_WASP, const int TILE_MEGA_WASP, const int LENGTH_SEVEN);
void infest_edge(string grid[10][10], int xval, int yval, const int TILE_BLANK, const int TILE_BEE, const int TILE_WASP, const int TILE_MEGA_WASP, const int LENGTH, const int LENGTH_EIGHT, const int LENGTH_FOUR);


#endif
