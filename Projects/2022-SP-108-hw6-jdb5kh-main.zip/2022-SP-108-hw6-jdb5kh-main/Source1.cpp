#include <iostream>
#include <string>
#include "Header1.h"
using namespace std;

bool isEdgecord(int airdrop[], const int LENGTH, const int TILE_BLANK) {
    if (airdrop[0] <= LENGTH && airdrop[1] == TILE_BLANK) {
        return true;
    }
    else if (airdrop[0] == LENGTH && airdrop[1] <= TILE_BLANK) {
        return true;
    }
    else if (airdrop[0] <= LENGTH && airdrop[1] == LENGTH) {
        return true;
    }
    else if (airdrop[0] == LENGTH && airdrop[1] <= TILE_BLANK) {
        return true;
    }
	
    else {
        return false;
    }


}

void infest_mid(string grid[][10], int xval, int yval, const int TILE_BLANK, const int TILE_BEE, const int TILE_WASP, const int TILE_MEGA_WASP, const int LENGTH_SEVEN){
	int temp_array[8];
	int temp_num;
	
	
	if(grid[xval][yval] == "_"){
		temp_num = TILE_BLANK;
	}else if(grid[xval][yval] == "B"){
		temp_num = TILE_BEE;	
	}else if(grid[xval][yval] == "W"){
		temp_num = TILE_WASP;
	}else if(grid[xval][yval] == "T"){
		temp_num = TILE_MEGA_WASP;
	}
	
	
	


	
	
	if(grid[xval+1][yval] == "_"){
		temp_array[0] = TILE_BLANK;
	}else if(grid[xval+1][yval] == "B"){
		temp_array[0] = TILE_BEE;	
	}else if(grid[xval+1][yval] == "W"){
		temp_array[0] = TILE_WASP;
	}else if(grid[xval+1][yval] == "T"){
		temp_array[0] = TILE_MEGA_WASP;
	}
		
	if(grid[xval][yval+1] == "_"){
		temp_array[1] = TILE_BLANK;
	}else if(grid[xval][yval+1] == "B"){
		temp_array[1] = TILE_BEE;	
	}else if(grid[xval][yval+1] == "W"){
		temp_array[1] = TILE_WASP;
	}else if(grid[xval][yval+1] == "T"){
		temp_array[1] = TILE_MEGA_WASP;
	}
		
	if(grid[xval+1][yval+1] == "_"){
		temp_array[2] = TILE_BLANK;
	}else if(grid[xval+1][yval+1] == "B"){
		temp_array[2] = TILE_BEE;	
	}else if(grid[xval+1][yval+1] == "W"){
		temp_array[2] = TILE_WASP;
	}else if(grid[xval+1][yval+1] == "T"){
		temp_array[2] = TILE_MEGA_WASP;
	}		
	
	if(grid[xval-1][yval] == "_"){
		temp_array[3] = TILE_BLANK;
	}else if(grid[xval-1][yval] == "B"){
		temp_array[3] = TILE_BEE;	
	}else if(grid[xval-1][yval] == "W"){
		temp_array[3] = TILE_WASP;
	}else if(grid[xval-1][yval] == "T"){
		temp_array[3] = TILE_MEGA_WASP;
	}		
		
	if(grid[xval][yval-1] == "_"){
		temp_array[4] = TILE_BLANK;
	}else if(grid[xval][yval-1] == "B"){
		temp_array[4] = TILE_BEE;	
	}else if(grid[xval][yval-1] == "W"){
		temp_array[4] = TILE_WASP;
	}else if(grid[xval][yval-1] == "T"){
		temp_array[4] = TILE_MEGA_WASP;
	}		
		
	if(grid[xval-1][yval-1] == "_"){
		temp_array[5] = TILE_BLANK;
	}else if(grid[xval-1][yval-1] == "B"){
		temp_array[5] = TILE_BEE;	
	}else if(grid[xval-1][yval-1] == "W"){
		temp_array[5] = TILE_WASP;
	}else if(grid[xval-1][yval-1] == "T"){
		temp_array[5] = TILE_MEGA_WASP;
	}		
		
	if(grid[xval+1][yval-1] == "_"){
		temp_array[6] = TILE_BLANK;
	}else if(grid[xval+1][yval-1] == "B"){
		temp_array[6] = TILE_BEE;	
	}else if(grid[xval+1][yval-1] == "W"){
		temp_array[6] = TILE_WASP;
	}else if(grid[xval+1][yval-1] == "T"){
		temp_array[6] = TILE_MEGA_WASP;
	}		
		
	if(grid[xval-1][yval+1] == "_"){
		temp_array[7] = TILE_BLANK;
	}else if(grid[xval-1][yval+1] == "B"){
		temp_array[7] = TILE_BEE;	
	}else if(grid[xval-1][yval+1] == "W"){
		temp_array[7] = TILE_WASP;
	}else if(grid[xval-1][yval+1] == "T"){
		temp_array[7] = TILE_MEGA_WASP;
	}
	
	
	
	
	if(grid[xval+1][yval] == "_" && grid[xval][yval+1] == "_" && grid[xval+1][yval+1] == "_" && grid[xval-1][yval] == "_" && grid[xval][yval-1] == "_" && grid[xval-1][yval-1] == "_" && grid[xval+1][yval-1] == "_" && grid[xval-1][yval+1] == "_"){
		for(int a = 0; a<=LENGTH_SEVEN; a++){
			temp_array[a] = temp_num;

		}
	}else{
	
	for(int k = 0; k<=LENGTH_SEVEN; k++){
		if(temp_array[k] < TILE_MEGA_WASP){
			temp_array[k] = temp_array[k] +TILE_BEE;
		}
	}
	
	}
	
	if(temp_array[0] == TILE_BLANK){
		grid[xval+1][yval] = "_";
	}else if(temp_array[0] == TILE_BEE){
		grid[xval+1][yval] = "B";
	}else if(temp_array[0] == TILE_WASP){
		grid[xval+1][yval] = "W";
	}else if(temp_array[0] == TILE_MEGA_WASP){
		grid[xval+1][yval] = "T";
	}
	
	
	if(temp_array[1] == TILE_BLANK){
		grid[xval][yval+1] = "_";
	}else if(temp_array[1] == TILE_BEE){
		grid[xval][yval+1] = "B";
	}else if(temp_array[1] == TILE_WASP){
		grid[xval][yval+1] = "W";
	}else if(temp_array[1] == TILE_MEGA_WASP){
		grid[xval][yval+1] = "T";
	}
	
	
	
	if(temp_array[2] == TILE_BLANK){
		grid[xval+1][yval+1] = "_";
	}else if(temp_array[2] == TILE_BEE){
		grid[xval+1][yval+1] = "B";
	}else if(temp_array[2] == TILE_WASP){
		grid[xval+1][yval+1] = "W";
	}else if(temp_array[2] == TILE_MEGA_WASP){
		grid[xval+1][yval+1] = "T";
	}
	
	

	if(temp_array[3] == TILE_BLANK){
		grid[xval-1][yval] = "_";
	}else if(temp_array[3] == TILE_BEE){
		grid[xval-1][yval] = "B";
	}else if(temp_array[3] == TILE_WASP){
		grid[xval-1][yval] = "W";
	}else if(temp_array[3] == TILE_MEGA_WASP){
		grid[xval-1][yval] = "T";
	}
	
	
	if(temp_array[4] == TILE_BLANK){
		grid[xval][yval-1] = "_";
	}else if(temp_array[4] == TILE_BEE){
		grid[xval][yval-1] = "B";
	}else if(temp_array[4] == TILE_WASP){
		grid[xval][yval-1] = "W";
	}else if(temp_array[4] == TILE_MEGA_WASP){
		grid[xval][yval-1] = "T";
	}
	
	
	if(temp_array[5] == TILE_BLANK){
		grid[xval-1][yval-1] = "_";
	}else if(temp_array[5] == TILE_BEE){
		grid[xval-1][yval-1] = "B";
	}else if(temp_array[5] == TILE_WASP){
		grid[xval-1][yval-1] = "W";
	}else if(temp_array[5] == TILE_MEGA_WASP){
		grid[xval-1][yval-1] = "T";
	}
	
	
	
	
	if(temp_array[6] == TILE_BLANK){
		grid[xval+1][yval-1] = "_";
	}else if(temp_array[6] == TILE_BEE){
		grid[xval+1][yval-1] = "B";
	}else if(temp_array[6] == TILE_WASP){
		grid[xval+1][yval-1] = "W";
	}else if(temp_array[6] == TILE_MEGA_WASP){
		grid[xval+1][yval-1] = "T";
	}
	
	
	
	if(temp_array[7] == TILE_BLANK){
		grid[xval-1][yval+1] = "_";
	}else if(temp_array[7] == TILE_BEE){
		grid[xval-1][yval+1] = "B";
	}else if(temp_array[7] == TILE_WASP){
		grid[xval-1][yval+1] = "W";
	}else if(temp_array[7] == TILE_MEGA_WASP){
		grid[xval-1][yval+1] = "T";
	}
		  
	    
 
}

void infest_edge(string grid[][10], int xval, int yval, const int TILE_BLANK, const int TILE_BEE, const int TILE_WASP, const int TILE_MEGA_WASP, const int LENGTH, const int LENGTH_EIGHT, const int LENGTH_FOUR){
	int temp_array_two[5];
	
	
	
	if(xval == TILE_BLANK && yval == TILE_BLANK){ //top left corner
		if(grid[xval+1][yval] == "_"){
			temp_array_two[0] = TILE_BLANK;
		}else if(grid[xval+1][yval] == "B"){
			temp_array_two[0] = TILE_BEE;	
		}else if(grid[xval+1][yval] == "W"){
			temp_array_two[0] = TILE_WASP;		
		}else if(grid[xval+1][yval] == "T"){
			temp_array_two[0] = TILE_MEGA_WASP;
		}
			
		if(grid[xval][yval+1] == "_"){
			temp_array_two[1] = TILE_BLANK;
		}else if(grid[xval][yval+1] == "B"){
			temp_array_two[1] = TILE_BEE;	
		}else if(grid[xval][yval+1] == "W"){
			temp_array_two[1] = TILE_WASP;		
		}else if(grid[xval][yval+1] == "T"){
			temp_array_two[1] = TILE_MEGA_WASP;
		}
		
		if(grid[xval+1][yval+1] == "_"){
			temp_array_two[2] = TILE_BLANK;
		}else if(grid[xval+1][yval+1] == "B"){
			temp_array_two[2] = TILE_BEE;	
		}else if(grid[xval+1][yval+1] == "W"){
			temp_array_two[2] = TILE_WASP;		
		}else if(grid[xval+1][yval+1] == "T"){
			temp_array_two[2] = TILE_MEGA_WASP;
		}
		
		
		for(int g = 0; g<= TILE_WASP; g++){
			if(temp_array_two[g] < TILE_MEGA_WASP){
				temp_array_two[g] = temp_array_two[g] + TILE_BEE;
				
				}
			}
		
		
		
		if(temp_array_two[0] == TILE_BLANK){
			grid[xval+1][yval] = "_";
		}else if(temp_array_two[0] == TILE_BEE){
			grid[xval+1][yval] = "B";
		}else if(temp_array_two[0] == TILE_WASP){
			grid[xval+1][yval] = "W";
		}else if(temp_array_two[0] == TILE_MEGA_WASP){
			grid[xval+1][yval] = "T";
		}
		
		if(temp_array_two[1] == TILE_BLANK){
			grid[xval][yval+1] = "_";
		}else if(temp_array_two[1] == TILE_BEE){
			grid[xval][yval+1] = "B";
		}else if(temp_array_two[1] == TILE_WASP){
			grid[xval][yval+1] = "W";
		}else if(temp_array_two[1] == TILE_MEGA_WASP){
			grid[xval][yval+1] = "T";
		}
		
		
		if(temp_array_two[2] == TILE_BLANK){
			grid[xval+1][yval+1] = "_";
		}else if(temp_array_two[2] == TILE_BEE){
			grid[xval+1][yval+1] = "B";
		}else if(temp_array_two[2] == TILE_WASP){
			grid[xval+1][yval+1] = "W";
		}else if(temp_array_two[2] == TILE_MEGA_WASP){
			grid[xval+1][yval+1] = "T";
		}
			
		
	}else if(xval == LENGTH && yval == TILE_BLANK){ //bot left corner
	
		if(grid[xval-1][yval] == "_"){
			temp_array_two[0] = TILE_BLANK;
		}else if(grid[xval-1][yval] == "B"){
			temp_array_two[0] = TILE_BEE;	
		}else if(grid[xval-1][yval] == "W"){
			temp_array_two[0] = TILE_WASP;		
		}else if(grid[xval-1][yval] == "T"){
			temp_array_two[0] = TILE_MEGA_WASP;
		}
			
		if(grid[xval][yval+1] == "_"){
			temp_array_two[1] = TILE_BLANK;
		}else if(grid[xval][yval+1] == "B"){
			temp_array_two[1] = TILE_BEE;	
		}else if(grid[xval][yval+1] == "W"){
			temp_array_two[1] = TILE_WASP;		
		}else if(grid[xval][yval+1] == "T"){
			temp_array_two[1] = TILE_MEGA_WASP;
		}
		
		if(grid[xval-1][yval+1] == "_"){
			temp_array_two[2] = TILE_BLANK;
		}else if(grid[xval-1][yval+1] == "B"){
			temp_array_two[2] = TILE_BEE;	
		}else if(grid[xval-1][yval+1] == "W"){
			temp_array_two[2] = TILE_WASP;		
		}else if(grid[xval-1][yval+1] == "T"){
			temp_array_two[2] = TILE_MEGA_WASP;
		}
		
		for(int v = 0; v<= TILE_WASP; v++){
			if(temp_array_two[v] < TILE_MEGA_WASP){
				temp_array_two[v] = temp_array_two[v] + TILE_BEE;
		}
		}
		
		if(temp_array_two[0] == TILE_BLANK){
			grid[xval-1][yval] = "_";
		}else if(temp_array_two[0] == TILE_BEE){
			grid[xval-1][yval] = "B";
		}else if(temp_array_two[0] == TILE_WASP){
			grid[xval-1][yval] = "W";
		}else if(temp_array_two[0] == TILE_MEGA_WASP){
			grid[xval-1][yval] = "T";
		}
		
		if(temp_array_two[1] == TILE_BLANK){
			grid[xval][yval+1] = "_";
		}else if(temp_array_two[1] == TILE_BEE){
			grid[xval][yval+1] = "B";
		}else if(temp_array_two[1] == TILE_WASP){
			grid[xval][yval+1] = "W";
		}else if(temp_array_two[1] == TILE_MEGA_WASP){
			grid[xval][yval+1] = "T";
		}
		
		if(temp_array_two[2] == TILE_BLANK){
			grid[xval-1][yval+1] = "_";
		}else if(temp_array_two[2] == TILE_BEE){
			grid[xval-1][yval+1] = "B";
		}else if(temp_array_two[2] == TILE_WASP){
			grid[xval-1][yval+1] = "W";
		}else if(temp_array_two[2] == TILE_MEGA_WASP){
			grid[xval-1][yval+1] = "T";
		}
		
	}else if(xval == LENGTH && yval == LENGTH){ //bot right corner
		if(grid[xval][yval-1] == "_"){
			temp_array_two[0] = TILE_BLANK;
		}else if(grid[xval][yval-1] == "B"){
			temp_array_two[0] = TILE_BEE;	
		}else if(grid[xval][yval-1] == "W"){
			temp_array_two[0] = TILE_WASP;		
		}else if(grid[xval][yval-1] == "T"){
			temp_array_two[0] = TILE_MEGA_WASP;
		}
			
		if(grid[xval-1][yval-1] == "_"){
			temp_array_two[1] = TILE_BLANK;
		}else if(grid[xval-1][yval-1] == "B"){
			temp_array_two[1] = TILE_BEE;	
		}else if(grid[xval-1][yval-1] == "W"){
			temp_array_two[1] = TILE_WASP;		
		}else if(grid[xval-1][yval-1] == "T"){
			temp_array_two[1] = 3;
		}
		
		if(grid[xval-1][yval] == "_"){
			temp_array_two[2] = TILE_BLANK;
		}else if(grid[xval-1][yval] == "B"){
			temp_array_two[2] = TILE_BEE;	
		}else if(grid[xval-1][yval] == "W"){
			temp_array_two[2] = TILE_WASP;		
		}else if(grid[xval-1][yval] == "T"){
			temp_array_two[2] = TILE_MEGA_WASP;
		}
		
		for(int g = 0; g<= TILE_WASP; g++){
			if(temp_array_two[g] < TILE_MEGA_WASP){
				temp_array_two[g] = temp_array_two[g] + TILE_BEE;
		}
		}
		
		if(temp_array_two[0] == TILE_BLANK){
			grid[xval][yval-1] = "_";
		}else if(temp_array_two[0] == TILE_BEE){
			grid[xval][yval-1] = "B";
		}else if(temp_array_two[0] == TILE_WASP){
			grid[xval][yval-1] = "W";
		}else if(temp_array_two[0] == TILE_MEGA_WASP){
			grid[xval][yval-1] = "T";
		}
		
		if(temp_array_two[1] == TILE_BLANK){
			grid[xval-1][yval-1] = "_";
		}else if(temp_array_two[1] == TILE_BEE){
			grid[xval-1][yval-1] = "B";
		}else if(temp_array_two[1] == TILE_WASP){
			grid[xval-1][yval-1] = "W";
		}else if(temp_array_two[1] == TILE_MEGA_WASP){
			grid[xval-1][yval-1] = "T";
		}
		
		if(temp_array_two[2] == TILE_BLANK){
			grid[xval-1][yval+1] = "_";
		}else if(temp_array_two[2] == TILE_BEE){
			grid[xval-1][yval+1] = "B";
		}else if(temp_array_two[2] == TILE_WASP){
			grid[xval-1][yval+1] = "W";
		}else if(temp_array_two[2] == TILE_MEGA_WASP){
			grid[xval-1][yval+1] = "T";
		}
		
	
		
		
	}else if(xval == TILE_BLANK && yval == LENGTH){ //top right corner
		if(grid[xval][yval-1] == "_"){
			temp_array_two[0] = TILE_BLANK;
		}else if(grid[xval][yval-1] == "B"){
			temp_array_two[0] = TILE_BEE;	
		}else if(grid[xval][yval-1] == "W"){
			temp_array_two[0] = TILE_WASP;		
		}else if(grid[xval][yval-1] == "T"){
			temp_array_two[0] = TILE_MEGA_WASP;
		}
			
		if(grid[xval+1][yval-1] == "_"){
			temp_array_two[1] = TILE_BLANK;
		}else if(grid[xval+1][yval-1] == "B"){
			temp_array_two[1] = TILE_BEE;	
		}else if(grid[xval+1][yval-1] == "W"){
			temp_array_two[1] = TILE_WASP;		
		}else if(grid[xval+1][yval-1] == "T"){
			temp_array_two[1] = TILE_MEGA_WASP;
		}
		
		if(grid[xval+1][yval] == "_"){
			temp_array_two[2] =TILE_BLANK;
		}else if(grid[xval+1][yval] == "B"){
			temp_array_two[2] = TILE_BEE;	
		}else if(grid[xval+1][yval] == "W"){
			temp_array_two[2] = TILE_WASP;		
		}else if(grid[xval+1][yval] == "T"){
			temp_array_two[2] = TILE_MEGA_WASP;
		}
		
		for(int n = 0; n<= TILE_WASP; n++){
			if(temp_array_two[n] < TILE_MEGA_WASP){
				temp_array_two[n] = temp_array_two[n] +TILE_BEE;
			}
		}
		
		
		if(temp_array_two[0] == TILE_BLANK){
			grid[xval][yval-1] = "_";
		}else if(temp_array_two[0] == TILE_BEE){
			grid[xval][yval-1] = "B";
		}else if(temp_array_two[0] == TILE_WASP){
			grid[xval][yval-1] = "W";
		}else if(temp_array_two[0] == TILE_MEGA_WASP){
			grid[xval][yval-1] = "T";
		}
		
		if(temp_array_two[1] == TILE_BLANK){
			grid[xval+1][yval-1] = "_";
		}else if(temp_array_two[1] == TILE_BEE){
			grid[xval+1][yval-1] = "B";
		}else if(temp_array_two[1] == TILE_WASP){
			grid[xval+1][yval-1] = "W";
		}else if(temp_array_two[1] == TILE_MEGA_WASP){
			grid[xval+1][yval-1] = "T";
		}
		
		
		if(temp_array_two[2] == TILE_BLANK){
			grid[xval+1][yval] = "_";
		}else if(temp_array_two[2] == TILE_BEE){
			grid[xval+1][yval] = "B";
		}else if(temp_array_two[2] == TILE_WASP){
			grid[xval+1][yval] = "W";
		}else if(temp_array_two[2] == TILE_MEGA_WASP){
			grid[xval+1][yval] = "T";
		}
		
	}else{
		if(xval == TILE_BLANK && yval <= LENGTH_EIGHT){ //top edge
		
		if(grid[xval][yval-1] == "_"){
			temp_array_two[0] = TILE_BLANK;
		}else if(grid[xval][yval-1] == "B"){
			temp_array_two[0] = TILE_BEE;	
		}else if(grid[xval][yval-1] == "W"){
			temp_array_two[0] = TILE_WASP;		
		}else if(grid[xval][yval-1] == "T"){
			temp_array_two[0] = TILE_MEGA_WASP;
		}
		
		if(grid[xval+1][yval-1] == "_"){
			temp_array_two[1] = TILE_BLANK;
		}else if(grid[xval+1][yval-1] == "B"){
			temp_array_two[1] = TILE_BEE;	
		}else if(grid[xval+1][yval-1] == "W"){
			temp_array_two[1] = TILE_WASP;		
		}else if(grid[xval+1][yval-1] == "T"){
			temp_array_two[1] = 3;
		}
		
		if(grid[xval+1][yval] == "_"){
			temp_array_two[2] = TILE_BLANK;
		}else if(grid[xval+1][yval] == "B"){
			temp_array_two[2] = TILE_BEE;	
		}else if(grid[xval+1][yval] == "W"){
			temp_array_two[2] = TILE_WASP;		
		}else if(grid[xval+1][yval] == "T"){
			temp_array_two[2] = TILE_MEGA_WASP;
		}
			
		if(grid[xval+1][yval+1] == "_"){
			temp_array_two[3] = TILE_BLANK;
		}else if(grid[xval+1][yval+1] == "B"){
			temp_array_two[3] = TILE_BEE;	
		}else if(grid[xval+1][yval+1] == "W"){
			temp_array_two[3] = TILE_WASP;		
		}else if(grid[xval+1][yval+1] == "T"){
			temp_array_two[3] = TILE_MEGA_WASP;
		}	
		
		if(grid[xval][yval+1] == "_"){
			temp_array_two[4] = TILE_BLANK;
		}else if(grid[xval][yval+1] == "B"){
			temp_array_two[4] = TILE_BEE;	
		}else if(grid[xval][yval+1] == "W"){
			temp_array_two[4] = TILE_WASP;		
		}else if(grid[xval][yval+1] == "T"){
			temp_array_two[4] = TILE_MEGA_WASP;
		}
			
		for(int p = 0; p<= LENGTH_FOUR; p++){
			if(temp_array_two[p] < TILE_MEGA_WASP){
				temp_array_two[p] = temp_array_two[p] +TILE_BEE;
			}
		}
		
		if(temp_array_two[0] == TILE_BLANK){
			grid[xval][yval-1] = "_";
		}else if(temp_array_two[0] == TILE_BEE){
			grid[xval][yval-1] = "B";
		}else if(temp_array_two[0] == TILE_WASP){
			grid[xval][yval-1] = "W";
		}else if(temp_array_two[0] == TILE_MEGA_WASP){
			grid[xval][yval-1] = "T";
		}
		
		if(temp_array_two[1] == TILE_BLANK){
			grid[xval+1][yval-1] = "_";
		}else if(temp_array_two[1] == TILE_BEE){
			grid[xval+1][yval-1] = "B";
		}else if(temp_array_two[1] == TILE_WASP){
			grid[xval+1][yval-1] = "W";
		}else if(temp_array_two[1] == TILE_MEGA_WASP){
			grid[xval+1][yval-1] = "T";
		}
		
		
		if(temp_array_two[2] == TILE_BLANK){
			grid[xval+1][yval] = "_";
		}else if(temp_array_two[2] == TILE_BEE){
			grid[xval+1][yval] = "B";
		}else if(temp_array_two[2] == TILE_WASP){
			grid[xval+1][yval] = "W";
		}else if(temp_array_two[2] == 3){
			grid[xval+1][yval] = "T";
		}
		
		if(temp_array_two[3] == TILE_BLANK){
			grid[xval+1][yval+1] = "_";
		}else if(temp_array_two[3] == TILE_BEE){
			grid[xval+1][yval+1] = "B";
		}else if(temp_array_two[3] == TILE_WASP){
			grid[xval+1][yval+1] = "W";
		}else if(temp_array_two[3] == TILE_MEGA_WASP){
			grid[xval+1][yval+1] = "T";
		}
		
		if(temp_array_two[4] == TILE_BLANK){
			grid[xval][yval+1] = "_";
		}else if(temp_array_two[4] == TILE_BEE){
			grid[xval][yval+1] = "B";
		}else if(temp_array_two[4] == TILE_WASP){
			grid[xval][yval+1] = "W";
		}else if(temp_array_two[4] == 3){
			grid[xval][yval+1] = "T";
		}
		
			
		}else if(xval <= LENGTH_EIGHT && yval == TILE_BLANK){ //left edge
		
		if(grid[xval-1][yval] == "_"){
			temp_array_two[0] = TILE_BLANK;
		}else if(grid[xval-1][yval] == "B"){
			temp_array_two[0] = TILE_BEE;	
		}else if(grid[xval-1][yval] == "W"){
			temp_array_two[0] = TILE_WASP;		
		}else if(grid[xval-1][yval] == "T"){
			temp_array_two[0] = TILE_MEGA_WASP;
		}
		
		if(grid[xval-1][yval+1] == "_"){
			temp_array_two[1] = TILE_BLANK;
		}else if(grid[xval-1][yval+1] == "B"){
			temp_array_two[1] = TILE_BEE;	
		}else if(grid[xval-1][yval+1] == "W"){
			temp_array_two[1] = TILE_WASP;		
		}else if(grid[xval-1][yval+1] == "T"){
			temp_array_two[1] = TILE_MEGA_WASP;
		}
		
		if(grid[xval+1][yval+1] == "_"){
			temp_array_two[2] = TILE_BLANK;
		}else if(grid[xval+1][yval+1] == "B"){
			temp_array_two[2] = TILE_BEE;	
		}else if(grid[xval+1][yval+1] == "W"){
			temp_array_two[2] = TILE_WASP;		
		}else if(grid[xval+1][yval+1] == "T"){
			temp_array_two[2] = TILE_MEGA_WASP;
		}
			
		if(grid[xval+1][yval+1] == "_"){
			temp_array_two[3] = TILE_BLANK;
		}else if(grid[xval+1][yval+1] == "B"){
			temp_array_two[3] = TILE_BEE;	
		}else if(grid[xval+1][yval+1] == "W"){
			temp_array_two[3] = TILE_WASP;		
		}else if(grid[xval+1][yval+1] == "T"){
			temp_array_two[3] = TILE_MEGA_WASP;
		}	
		
		if(grid[xval+1][yval] == "_"){
			temp_array_two[4] = TILE_BLANK;
		}else if(grid[xval+1][yval] == "B"){
			temp_array_two[4] = TILE_BEE;	
		}else if(grid[xval+1][yval] == "W"){
			temp_array_two[4] = TILE_WASP;		
		}else if(grid[xval+1][yval] == "T"){
			temp_array_two[4] = TILE_MEGA_WASP;
		}
			
		for(int q = 0; q<= LENGTH_FOUR; q++){
			if(temp_array_two[q] < TILE_MEGA_WASP){
				temp_array_two[q] = temp_array_two[q] +TILE_BEE;
			}
		}
		
		if(temp_array_two[0] == TILE_BLANK){
			grid[xval-1][yval] = "_";
		}else if(temp_array_two[0] == TILE_BEE){
			grid[xval-1][yval] = "B";
		}else if(temp_array_two[0] == TILE_WASP){
			grid[xval-1][yval] = "W";
		}else if(temp_array_two[0] == TILE_MEGA_WASP){
			grid[xval-1][yval] = "T";
		}
		
		if(temp_array_two[1] == TILE_BLANK){
			grid[xval-1][yval+1] = "_";
		}else if(temp_array_two[1] == TILE_BEE){
			grid[xval-1][yval+1] = "B";
		}else if(temp_array_two[1] == TILE_WASP){
			grid[xval-1][yval+1] = "W";
		}else if(temp_array_two[1] == TILE_MEGA_WASP){
			grid[xval-1][yval+1] = "T";
		}
		
		
		if(temp_array_two[2] == TILE_BLANK){
			grid[xval+1][yval+1] = "_";
		}else if(temp_array_two[2] == TILE_BEE){
			grid[xval+1][yval+1] = "B";
		}else if(temp_array_two[2] == TILE_WASP){
			grid[xval+1][yval+1] = "W";
		}else if(temp_array_two[2] == TILE_MEGA_WASP){
			grid[xval+1][yval+1] = "T";
		}
		
		if(temp_array_two[3] == TILE_BLANK){
			grid[xval+1][yval+1] = "_";
		}else if(temp_array_two[3] == TILE_BEE){
			grid[xval+1][yval+1] = "B";
		}else if(temp_array_two[3] == TILE_WASP){
			grid[xval+1][yval+1] = "W";
		}else if(temp_array_two[3] == TILE_MEGA_WASP){
			grid[xval+1][yval+1] = "T";
		}
		
		if(temp_array_two[4] == TILE_BLANK){
			grid[xval+1][yval] = "_";
		}else if(temp_array_two[4] == TILE_BEE){
			grid[xval+1][yval] = "B";
		}else if(temp_array_two[4] == TILE_WASP){
			grid[xval+1][yval] = "W";
		}else if(temp_array_two[4] == TILE_MEGA_WASP){
			grid[xval+1][yval] = "T";
		}
			
		}else if(xval == LENGTH && yval <= LENGTH_EIGHT){ //bot edge
		
		if(grid[xval][yval-1] == "_"){
			temp_array_two[0] = TILE_BLANK;
		}else if(grid[xval][yval-1] == "B"){
			temp_array_two[0] = TILE_BEE;	
		}else if(grid[xval][yval-1] == "W"){
			temp_array_two[0] = TILE_WASP;		
		}else if(grid[xval][yval-1] == "T"){
			temp_array_two[0] = TILE_MEGA_WASP;
		}
		
		if(grid[xval-1][yval-1] == "_"){
			temp_array_two[1] = TILE_BLANK;
		}else if(grid[xval-1][yval-1] == "B"){
			temp_array_two[1] = TILE_BEE;	
		}else if(grid[xval-1][yval-1] == "W"){
			temp_array_two[1] = TILE_WASP;		
		}else if(grid[xval-1][yval-1] == "T"){
			temp_array_two[1] = TILE_MEGA_WASP;
		}
		
		if(grid[xval-1][yval] == "_"){
			temp_array_two[2] = TILE_BLANK;
		}else if(grid[xval-1][yval] == "B"){
			temp_array_two[2] = TILE_BEE;	
		}else if(grid[xval-1][yval] == "W"){
			temp_array_two[2] = TILE_WASP;		
		}else if(grid[xval-1][yval] == "T"){
			temp_array_two[2] = TILE_MEGA_WASP;
		}
			
		if(grid[xval-1][yval+1] == "_"){
			temp_array_two[3] = TILE_BLANK;
		}else if(grid[xval-1][yval+1] == "B"){
			temp_array_two[3] = TILE_BEE;	
		}else if(grid[xval-1][yval+1] == "W"){
			temp_array_two[3] = TILE_WASP;		
		}else if(grid[xval-1][yval+1] == "T"){
			temp_array_two[3] = TILE_MEGA_WASP;
		}	
		
		if(grid[xval][yval+1] == "_"){
			temp_array_two[4] = TILE_BLANK;
		}else if(grid[xval][yval+1] == "B"){
			temp_array_two[4] = TILE_BEE;	
		}else if(grid[xval][yval+1] == "W"){
			temp_array_two[4] = TILE_WASP;		
		}else if(grid[xval][yval+1] == "T"){
			temp_array_two[4] = TILE_MEGA_WASP;
		}
			
		for(int f = 0; f<= LENGTH_FOUR; f++){
			if(temp_array_two[f] < TILE_MEGA_WASP){
				temp_array_two[f] = temp_array_two[f] + TILE_BEE;
			}
		}
		
		
		if(temp_array_two[0] == TILE_BLANK){
			grid[xval][yval-1] = "_";
		}else if(temp_array_two[0] == TILE_BEE){
			grid[xval][yval-1] = "B";
		}else if(temp_array_two[0] == TILE_WASP){
			grid[xval][yval-1] = "W";
		}else if(temp_array_two[0] == TILE_MEGA_WASP){
			grid[xval][yval-1] = "T";
		}
		
		if(temp_array_two[1] == TILE_BLANK){
			grid[xval-1][yval-1] = "_";
		}else if(temp_array_two[1] == TILE_BEE){
			grid[xval-1][yval-1] = "B";
		}else if(temp_array_two[1] == TILE_WASP){
			grid[xval-1][yval-1] = "W";
		}else if(temp_array_two[1] == TILE_MEGA_WASP){
			grid[xval-1][yval-1] = "T";
		}
		
		
		if(temp_array_two[2] == TILE_BLANK){
			grid[xval-1][yval] = "_";
		}else if(temp_array_two[2] == TILE_BEE){
			grid[xval-1][yval] = "B";
		}else if(temp_array_two[2] == TILE_WASP){
			grid[xval-1][yval] = "W";
		}else if(temp_array_two[2] == TILE_MEGA_WASP){
			grid[xval-1][yval] = "T";
		}
		
		if(temp_array_two[3] == TILE_BLANK){
			grid[xval-1][yval+1] = "_";
		}else if(temp_array_two[3] == TILE_BEE){
			grid[xval-1][yval+1] = "B";
		}else if(temp_array_two[3] == TILE_WASP){
			grid[xval-1][yval+1] = "W";
		}else if(temp_array_two[3] == TILE_MEGA_WASP){
			grid[xval-1][yval+1] = "T";
		}
		
		if(temp_array_two[4] == TILE_BLANK){
			grid[xval][yval+1] = "_";
		}else if(temp_array_two[4] == TILE_BEE){
			grid[xval][yval+1] = "B";
		}else if(temp_array_two[4] == TILE_WASP){
			grid[xval][yval+1] = "W";
		}else if(temp_array_two[4] == TILE_MEGA_WASP){
			grid[xval][yval+1] = "T";
		}
		
	
			
		}else if(xval <= LENGTH_EIGHT && yval == LENGTH){ //right edge
		
		if(grid[xval-1][yval] == "_"){
			temp_array_two[0] = TILE_BLANK;
		}else if(grid[xval-1][yval] == "B"){
			temp_array_two[0] = TILE_BEE;	
		}else if(grid[xval-1][yval] == "W"){
			temp_array_two[0] = TILE_WASP;		
		}else if(grid[xval-1][yval] == "T"){
			temp_array_two[0] = TILE_MEGA_WASP;
		}
		
		if(grid[xval-1][yval-1] == "_"){
			temp_array_two[1] = TILE_BLANK;
		}else if(grid[xval-1][yval-1] == "B"){
			temp_array_two[1] = TILE_BEE;	
		}else if(grid[xval-1][yval-1] == "W"){
			temp_array_two[1] = TILE_WASP;		
		}else if(grid[xval-1][yval-1] == "T"){
			temp_array_two[1] = TILE_MEGA_WASP;
		}
		
		if(grid[xval][yval-1] == "_"){
			temp_array_two[2] = TILE_BLANK;
		}else if(grid[xval][yval-1] == "B"){
			temp_array_two[2] = TILE_BEE;	
		}else if(grid[xval][yval-1] == "W"){
			temp_array_two[2] = TILE_WASP;		
		}else if(grid[xval][yval-1] == "T"){
			temp_array_two[2] = TILE_MEGA_WASP;
		}
			
		if(grid[xval+1][yval-1] == "_"){
			temp_array_two[3] = TILE_BLANK;
		}else if(grid[xval+1][yval-1] == "B"){
			temp_array_two[3] = TILE_BEE;	
		}else if(grid[xval+1][yval-1] == "W"){
			temp_array_two[3] = TILE_WASP;		
		}else if(grid[xval+1][yval-1] == "T"){
			temp_array_two[3] = TILE_MEGA_WASP;
		}	
		
		if(grid[xval+1][yval] == "_"){
			temp_array_two[4] = TILE_BLANK;
		}else if(grid[xval+1][yval] == "B"){
			temp_array_two[4] = TILE_BEE;	
		}else if(grid[xval+1][yval] == "W"){
			temp_array_two[4] = TILE_WASP;		
		}else if(grid[xval+1][yval] == "T"){
			temp_array_two[4] = TILE_MEGA_WASP;
		}
			
		for(int c = 0; c<= LENGTH_FOUR; c++){
			if(temp_array_two[c] < TILE_MEGA_WASP){
				temp_array_two[c] = temp_array_two[c] +TILE_BEE;
			}
		}
		
		
		if(temp_array_two[0] == TILE_BLANK){
			grid[xval-1][yval] = "_";
		}else if(temp_array_two[0] == TILE_BEE){
			grid[xval-1][yval] = "B";
		}else if(temp_array_two[0] == TILE_WASP){
			grid[xval-1][yval] = "W";
		}else if(temp_array_two[0] == TILE_MEGA_WASP){
			grid[xval-1][yval] = "T";
		}
		
		if(temp_array_two[1] == TILE_BLANK){
			grid[xval-1][yval-1] = "_";
		}else if(temp_array_two[1] == TILE_BEE){
			grid[xval-1][yval-1] = "B";
		}else if(temp_array_two[1] == TILE_WASP){
			grid[xval-1][yval-1] = "W";
		}else if(temp_array_two[1] == TILE_MEGA_WASP){
			grid[xval-1][yval-1] = "T";
		}
		
		if(temp_array_two[2] == TILE_BLANK){
			grid[xval][yval-1] = "_";
		}else if(temp_array_two[2] == TILE_BEE){
			grid[xval][yval-1] = "B";
		}else if(temp_array_two[2] == TILE_WASP){
			grid[xval][yval-1] = "W";
		}else if(temp_array_two[2] == TILE_MEGA_WASP){
			grid[xval][yval-1] = "T";
		}
		
		if(temp_array_two[3] == TILE_BLANK){
			grid[xval+1][yval-1] = "_";
		}else if(temp_array_two[3] == TILE_BEE){
			grid[xval+1][yval-1] = "B";
		}else if(temp_array_two[3] == TILE_WASP){
			grid[xval+1][yval-1] = "W";
		}else if(temp_array_two[3] == TILE_MEGA_WASP){
			grid[xval+1][yval-1] = "T";
		}
		
		if(temp_array_two[4] == TILE_BLANK){
			grid[xval+1][yval] = "_";
		}else if(temp_array_two[4] == TILE_BEE){
			grid[xval+1][yval] = "B";
		}else if(temp_array_two[4] == TILE_WASP){
			grid[xval+1][yval] = "W";
		}else if(temp_array_two[4] == TILE_MEGA_WASP){
			grid[xval+1][yval] = "T";
		}
		
	
		
		}
		
	
		
	}
	
	
}
	
	