//[grader] -2 This file should have a header with basic info, such as your name

#include <iostream>
#include <string>
#include <fstream>
#include "Header1.h"


using namespace std;

int main()
{
    const string INPUTFILE = "TextFile1.txt";
	const string OUTPUTFILE = "output.txt";
    ifstream fin;
	ofstream fout;
    char data;
    int airdropcord;
    string grid[10][10];
    int airdrop[2];
	int xval;
	int yval;
	const int TILE_BLANK = 0;
	const int TILE_BEE = 1;
	const int TILE_WASP = 2;
	const int TILE_MEGA_WASP = 3;
	const int LENGTH = 9;
	const int LENGTH_SEVEN = 7;
	const int LENGTH_EIGHT = 8;
	const int LENGTH_FOUR = 4;


    fin.open(INPUTFILE);

    for (int i = 0; i <= LENGTH; i++) {
        for (int j = 0; j <= LENGTH; j++) {
            fin >> data;
            grid[i][j] = data;
        }
    }



    while (fin >> airdropcord) {
        airdrop[0] = airdropcord;
        //cout << airdrop[0] << endl;
        fin >> airdropcord;
        airdrop[1] = airdropcord;
		
		xval = airdrop[0];
		yval = airdrop[1];
        //cout << airdrop[1] << endl;
		
		if(grid[xval][yval] == "_"){
			grid[xval][yval] = "B";
        }else if (isEdgecord(airdrop, LENGTH, TILE_BLANK) == true) {
			infest_edge(grid, xval, yval, TILE_BLANK, TILE_BEE, TILE_WASP, TILE_MEGA_WASP, LENGTH, LENGTH_EIGHT, LENGTH_FOUR);
        }else{
			infest_mid(grid, xval, yval, TILE_BLANK, TILE_BEE, TILE_WASP, TILE_MEGA_WASP, LENGTH_SEVEN);
        }

    }
    for (int h = 0; h <= LENGTH; h++) {
        for (int g = 0; g <= LENGTH; g++) {
            cout << grid[h][g];
        }
        cout << "\t" << endl;
    }
    fin.close();
	
	
	
	
	fout.open(OUTPUTFILE);
	
	for (int e = 0; e <= LENGTH; e++) {
        for (int q = 0; q <= LENGTH; q++) {
            fout << grid[e][q];
        }
		fout << "\t" << endl;
    }
	fout.close();

    return 0;
}










